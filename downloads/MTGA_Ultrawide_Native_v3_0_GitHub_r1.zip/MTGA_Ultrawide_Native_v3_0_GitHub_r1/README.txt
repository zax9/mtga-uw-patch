MTGA Ultrawide Patcher 3.0.0
Native Windows x64 application

The executable is 559,616 bytes (about 547 KiB). It is compiled C++17 with a
minimal Win32 GUI. It needs no .NET runtime, installer, or extra DLLs.

INSTALL
1. Extract the ZIP into a folder of your choice.
2. Close Arena and its launcher/updater.
3. Right-click MTGAUltrawidePatcher.exe and choose Run as administrator.
   Administrator access is needed to change files under Program Files;
   checking status alone does not require it.
4. The default folder is C:\Program Files\Wizards of the Coast\MTGA.
   It is checked automatically. Use Browse for another installation, or
   enter its folder and click Check.
5. If the check succeeds, click Install patch and wait for verification.
6. Start Arena normally. Enable fullscreen with Arena's graphics-settings
   checkbox. Test entering and leaving a bot match before regular play.

The patcher does not need to remain running. It sends no keystrokes and
does not change Arena's monitor-selection behavior.

RESTORE
Close Arena and its launcher/updater, run the patcher as administrator,
select the same folder, and click Restore original. Keep the original
backup files beside Core.dll; they are required for a verified restore.
Backups from patcher v1 and v2 are supported. Restore refuses a backup
that does not reproduce the exact currently patched file.

HOW IT WORKS
The patcher reads Core.dll as data, finds the relevant method through .NET
metadata, validates the instruction pattern, then changes one four-byte
floating-point constant in the fullscreen aspect-ratio check. The upper
limit becomes 2.4, covering 3440x1440 and 2560x1080 displays.

It makes a hash-named original backup, stages the changed file, and verifies
the replacement. Only recognized method logic is accepted. Changed offsets
and metadata tokens are supported; a future release that changes the
relevant logic may need an updated patcher. Unsupported builds are refused.

AFTER AN ARENA UPDATE
Run Check again. An update or launcher repair may replace Core.dll and
remove the patch. Reinstall only if this patcher recognizes the new build.
Do not copy an older Core.dll or backup over a newer Arena release.

VERIFICATION AND LIMITS
47 native parser/matcher checks and 32 install/restore checks passed on
Linux. The Windows executable was cross-compiled and its imports inspected.
The Win32 GUI, Windows file-replacement APIs, and actual Arena gameplay have
not been runtime-tested here. Only the supplied Arena release was tested;
other layouts were synthetic variations. Standalone-launcher enforcement remains
unconfirmed; check patch status after starting and exiting Arena normally.

SOURCE AND COMMAND LINE
Source is in source/. BUILD.md contains build instructions.
No arguments opens the GUI. Optional command-line actions are:

  MTGAUltrawidePatcher.exe status
  MTGAUltrawidePatcher.exe install
  MTGAUltrawidePatcher.exe restore
  MTGAUltrawidePatcher.exe status --game-path "D:\Games\MTGA"

The command-line interface uses the same validation and backup rules.

PUBLIC GITHUB PACKAGE REVISION 1
See README.md for the public project overview, subsequent user-reported
Windows result, usage disclaimer, and license information. This executable
and source are unchanged from the original v3.0.0 distribution.
